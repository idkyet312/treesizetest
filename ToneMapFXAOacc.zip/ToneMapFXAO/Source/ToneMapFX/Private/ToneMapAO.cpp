// Licensed under the zlib License. See LICENSE file in the project root.

#include "ToneMapAOShaders.h"

IMPLEMENT_GLOBAL_SHADER(FToneMapAOPS, "/Plugin/ToneMapFX/Private/ToneMapAO.usf", "AOPS", SF_Pixel);
IMPLEMENT_GLOBAL_SHADER(FToneMapAOBlurPS, "/Plugin/ToneMapFX/Private/ToneMapAOBlur.usf", "AOBlurPS", SF_Pixel);
IMPLEMENT_GLOBAL_SHADER(FToneMapAOTemporalPS, "/Plugin/ToneMapFX/Private/ToneMapAOTemporal.usf", "AOTemporalPS", SF_Pixel);
IMPLEMENT_GLOBAL_SHADER(FToneMapAOCompositePS, "/Plugin/ToneMapFX/Private/ToneMapAOComposite.usf", "AOCompositePS", SF_Pixel);
