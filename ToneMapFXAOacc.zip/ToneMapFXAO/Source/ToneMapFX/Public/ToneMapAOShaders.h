// Licensed under the zlib License. See LICENSE file in the project root.

#pragma once

#include "CoreMinimal.h"
#include "GlobalShader.h"
#include "ShaderParameterStruct.h"
#include "ScreenPass.h"

// =============================================================================
// Ambient Occlusion — Ground-Truth Visibility-Bitmask AO (GT-VBAO style)
//   Screen-space horizon AO from SceneDepth + GBuffer world normals.
//   Writes only the raw AO term (R) + linear scene depth (G) to a PF_G16R16F
//   target — it does NOT touch SceneColor. The grainy raw term is denoised by
//   FToneMapAOBlurPS and applied by FToneMapAOCompositePS. Deferred renderer
//   only — the caller skips this pass when depth / GBuffer normals are
//   unavailable (Forward / mobile).
// =============================================================================
class FToneMapAOPS : public FGlobalShader
{
public:
	DECLARE_GLOBAL_SHADER(FToneMapAOPS);
	SHADER_USE_PARAMETER_STRUCT(FToneMapAOPS, FGlobalShader);

	BEGIN_SHADER_PARAMETER_STRUCT(FParameters, )
		SHADER_PARAMETER_STRUCT_REF(FViewUniformShaderParameters, View)

		// Depth + GBuffer world normal inputs.
		// NOTE: prefixed with AO_ to avoid clashing with engine-global shader names
		// pulled in via Common.ush — "SceneDepthTexture" is an engine scene-texture
		// global, and "SvPositionToBufferUV" is a function defined in Common.ush.
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, AOSceneDepthTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, AOSceneDepthSampler)
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, GBufferNormalTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, GBufferNormalSampler)

		SHADER_PARAMETER(FScreenTransform, AOSvPositionToBufferUV)

		// x = Intensity (power), y = Radius (world units), z = NumSlices, w = StepsPerSlice
		SHADER_PARAMETER(FVector4f, AOParams)
		// x = Thickness, y = MaxDistance (world units, 0 = unlimited), z = unused, w = unused
		SHADER_PARAMETER(FVector4f, AOParams2)

		SHADER_PARAMETER(FVector2f, BufferInvSize)

		RENDER_TARGET_BINDING_SLOTS()
	END_SHADER_PARAMETER_STRUCT()

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters& Parameters)
	{
		return IsFeatureLevelSupported(Parameters.Platform, ERHIFeatureLevel::SM5);
	}
};

// =============================================================================
// AO denoise — separable depth-aware bilateral blur of the AO term.
//   Run horizontal then vertical. Reads RG (AO, depth), writes RG with R
//   smoothed across surfaces but preserved across depth edges.
// =============================================================================
class FToneMapAOBlurPS : public FGlobalShader
{
public:
	DECLARE_GLOBAL_SHADER(FToneMapAOBlurPS);
	SHADER_USE_PARAMETER_STRUCT(FToneMapAOBlurPS, FGlobalShader);

	BEGIN_SHADER_PARAMETER_STRUCT(FParameters, )
		SHADER_PARAMETER_STRUCT_REF(FViewUniformShaderParameters, View)
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, AOInputTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, AOInputSampler)
		SHADER_PARAMETER(FScreenTransform, SvPositionToAOUV)
		SHADER_PARAMETER(FVector2f, AOInputExtentInv)
		SHADER_PARAMETER(FVector2f, AOBlurDirection)
		SHADER_PARAMETER(float, AOBlurRadius)
		SHADER_PARAMETER(float, AOBlurDepthSharpness)
		RENDER_TARGET_BINDING_SLOTS()
	END_SHADER_PARAMETER_STRUCT()

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters& Parameters)
	{
		return IsFeatureLevelSupported(Parameters.Platform, ERHIFeatureLevel::SM5);
	}
};

// =============================================================================
// AO composite — multiply the denoised AO term into SceneColor (or, in debug
//   mode, output the AO term as greyscale). Final write of the AO chain.
// =============================================================================
class FToneMapAOCompositePS : public FGlobalShader
{
public:
	DECLARE_GLOBAL_SHADER(FToneMapAOCompositePS);
	SHADER_USE_PARAMETER_STRUCT(FToneMapAOCompositePS, FGlobalShader);

	BEGIN_SHADER_PARAMETER_STRUCT(FParameters, )
		SHADER_PARAMETER_STRUCT_REF(FViewUniformShaderParameters, View)
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, SceneColorTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, SceneColorSampler)
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, AOTermTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, AOTermSampler)
		SHADER_PARAMETER(FScreenTransform, SvPositionToSceneColorUV)
		SHADER_PARAMETER(FScreenTransform, SvPositionToAOTermUV)
		SHADER_PARAMETER(float, AOCompositeDebugView)
		SHADER_PARAMETER(float, AOCompositeDither)
		SHADER_PARAMETER(float, AOCompositeMultiBounce)
		RENDER_TARGET_BINDING_SLOTS()
	END_SHADER_PARAMETER_STRUCT()

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters& Parameters)
	{
		return IsFeatureLevelSupported(Parameters.Platform, ERHIFeatureLevel::SM5);
	}
};

// =============================================================================
// AO temporal accumulation — reproject last frame's AO through the velocity
//   buffer and blend, rejecting history on disocclusion. Runs between the AO
//   compute pass and the spatial blur. This is the main quality/stability win:
//   it lets the compute pass use far fewer samples while staying clean.
// =============================================================================
class FToneMapAOTemporalPS : public FGlobalShader
{
public:
	DECLARE_GLOBAL_SHADER(FToneMapAOTemporalPS);
	SHADER_USE_PARAMETER_STRUCT(FToneMapAOTemporalPS, FGlobalShader);

	BEGIN_SHADER_PARAMETER_STRUCT(FParameters, )
		SHADER_PARAMETER_STRUCT_REF(FViewUniformShaderParameters, View)
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, AOCurrentTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, AOCurrentSampler)
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, AOHistoryTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, AOHistorySampler)
		SHADER_PARAMETER_RDG_TEXTURE(Texture2D, AOVelocityTexture)
		SHADER_PARAMETER_SAMPLER(SamplerState, AOVelocitySampler)
		SHADER_PARAMETER(FScreenTransform, SvPositionToAOUV)
		SHADER_PARAMETER(FScreenTransform, SvPositionToVelocityUV)
		SHADER_PARAMETER(float, AOTemporalWeight)
		SHADER_PARAMETER(float, AOTemporalDepthTol)
		RENDER_TARGET_BINDING_SLOTS()
	END_SHADER_PARAMETER_STRUCT()

	static bool ShouldCompilePermutation(const FGlobalShaderPermutationParameters& Parameters)
	{
		return IsFeatureLevelSupported(Parameters.Platform, ERHIFeatureLevel::SM5);
	}
};
